<?php
    // Session
    include ("php/session.php");
    
    // Database Connection
    include ("php/dbcon.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <!--bostrap link-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>
<body>
    <!--Nav bar start-->
    <nav id="navbar-example2" class="navbar bg-body-tertiary px-3 mb-3 sticky-top  navbar-dark navcolor">
        <a class="navbar-brand">Admin</a>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="../superadmin/superadmin.php">Super Admin Page</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../approvalpage/approvalpage.php">Approval Page</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../dataentry/index.php">Data Entry Page</a>
            </li>
            <div class="navlogbtn">
                <li class="nav-item">
                    <a class="nav-link "><button class="logout-btn"
                            onclick="location.href='../loginpage/login/Logout.php'">Logout</button></a>
                </li>
            </div>
        </ul>
    </nav>
    <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%"
        data-bs-smooth-scroll="true" class="scrollspy-example bg-body-tertiary p-3 rounded-2" tabindex="0">
        <!--Nav bar End-->
        <center>
            <div style="margin: 0 auto;padding: 85px;border: 2px solid #6270EA;width:500px;height:425px">
                <?php
                    // Query to count total users
                    $sql2 = "SELECT COUNT(*) AS count FROM user";
                
                    //execute query
                    $result2 = $conn->query($sql2);
                
                    // Check if there are any results
                    if ($result2->num_rows > 0)
                    {
                    
                        // Fetch the result
                        $row2 = $result2->fetch_assoc(); 
                    
                        // Output total user count
                        echo "Total Users - " . $row2["count"] ."<br>";
                    }
                    else{echo "No Users Found";}
                
                    //query to count user types based on the type
                    $sql3 = "SELECT type, COUNT(*) AS count FROM user  GROUP BY type";
                
                    // Execute query
                    $result = $conn->query($sql3);
                
                    // Check if there are any results
                    if ($result->num_rows > 0)
                    {
                    
                        // Output data of each row
                        while($row = $result->fetch_assoc())
                        {
                            $role = '';
                            switch ($row["type"])
                            {
                                case 1: $role = "Admin";
                                        break;
                                case 2: $role = "User";
                                        break;
                                case 3: $role = "Super Admin";
                                        break;
                                case 4: $role = "Approval Officer";
                                        break;
                                case 5: $role = "Data Entry Officer";
                                        break;
                                default: $role = "Not Defined";
                            }
                        echo "Role: " . $role . " - " . $row["count"] . "<br>";
                }
            }
            else{echo "No Results found";}

            // Query to count total requests
            $sql4 = "SELECT COUNT(*) AS count FROM request";
            
            //execute query
            $result4 = $conn->query($sql4);
            
            // Check if there are any results
            if ($result4->num_rows > 0)
            {
                // Fetch the result
                $row4 = $result4->fetch_assoc();
                
                // Output total request count
                echo "<br>Total Requests - " . $row4["count"] ."<br>";
            }
            else {echo "No Requests Found";}
            
            // Query to count request types based on approval status
            $sql = "SELECT 
            CASE 
                WHEN approval_1_status = 'approved' AND approval_2_status = 'approved' AND approval_3_status = 'approved' THEN 'approved'
                WHEN approval_1_status = 'rejected' OR approval_2_status = 'rejected' OR approval_3_status = 'rejected' THEN 'rejected'
                ELSE 'pending'
            END AS status,
            COUNT(*) AS count 
            FROM 
            request
            GROUP BY 
            status";
            
            // Execute query
            $result = $conn->query($sql);
            
            // Check if there are any results
            if ($result->num_rows > 0)
            {
                // Output data of each row
                while($row = $result->fetch_assoc()){echo "Status: " . ucfirst($row["status"]) . " - Count: " . $row["count"] . "<br>";}
            }
            else {echo "No results found";}
            ?>
        </div>
    </center>
    <!--Java script-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
</body>
</html>