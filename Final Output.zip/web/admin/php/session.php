<?php
session_start();
if (!isset($_SESSION['user_id']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_SESSION['timeout']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
$_SESSION['LAST_ACTIVITY'] = time();
?>