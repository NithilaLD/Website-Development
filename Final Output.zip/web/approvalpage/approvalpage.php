<?php
    // Session
    include ("php/session.php");

    // Database Connection
    include ("php/dbcon.php");
    
    $appt = 4;
    $empid=$_SESSION['user_id'];
    if ($conn->connect_error){die("Connection failed:".$conn->connect_error);} 
    $sql="SELECT * FROM approver";
    $result=$conn->query($sql);
    if (!$result){die("Query failed:".$conn->error);}
    if($result->num_rows>0)
    {
        $row=$result->fetch_all(MYSQLI_ASSOC);;
        foreach ($row as $specificRowData)
        {
            $srd=$specificRowData['approvertype'];
            if($srd==1)
            {
                $emid=$specificRowData['employee_id'];
                if($emid==$empid){$appt=1;}
            }
            else if($srd==2)
            {
                $emid=$specificRowData['employee_id'];
                if($emid==$empid){$appt=2;}
            }
            else 
            {
                $emid=$specificRowData['employee_id'];
                if($emid==$empid){$appt=3;}
            }
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST')
    {
        if (isset($_POST['orderId']))
        {
            $orderId = $_POST['orderId'];
            $state = $_POST['orderState'];
            $currentDateTime = date('Y-m-d H:i:s');
            if($appt==1){$updateSql = "UPDATE request SET approval_1_status = '$state',approval_1_time='$currentDateTime' WHERE requestnumber = $orderId";}
            else if($appt==2){$updateSql = "UPDATE request SET approval_2_status = '$state',approval_2_time='$currentDateTime' WHERE requestnumber = $orderId";}
            else{$updateSql = "UPDATE request SET approval_3_status = '$state',approval_3_time='$currentDateTime' WHERE requestnumber = $orderId";}
            $updateResult = $conn->query($updateSql);
            if ($updateResult == false){echo "Error updating status: " . $conn->error;} 
            else{echo "Status updated successfully";}
            exit();
        }
        else
        {
            echo "No order ID received from JavaScript";
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Approval Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <script>
        function buttonClick(element,state)
        {
            var orderId = element.getAttribute('data-orderid');
            var orderState =  state;
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function (){if (xhr.readyState === 4 && xhr.status === 200){console.log(xhr.responseText);}};
            var data = 'orderId=' + encodeURIComponent(orderId) + '&orderState=' + encodeURIComponent(orderState);
            xhr.send(data);
           
            //Alert of udpate
            <?php if ($appt == 1): ?>
            alert("Updated Request Number: " + orderId + " Approval 1 Status As " + orderState);
            <?php elseif ($appt == 2): ?>
            alert("Updated Request Number: " + orderId + " Approval 2 Status As " + orderState);
            <?php else: ?>
            alert("Updated Request Number: " + orderId + " Approval 3 Status As " + orderState);
            <?php endif; ?>
            
            //Refresh page
            window.location.href= 'approvalpage.php' ;
        }
        </script>
    </head>
    <body>
        <button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button>
        
        <!-- Sidebar/menu -->
        <nav class="approve-sidebar " style="z-index:3;width:300px;font-weight:bold; " id="mySidebar"><br>
            <div class="btn-group-vertical btn-group-lg d-grid gap-2  mx-auto" role="group" aria-label="Vertical button group">
                <a href="#pending-pointer"><button type="button Pending-button " class="btn btn-outline-info "> Pending Requests</button></a>
                <a href="#approval-pointer"><button type="button Approve-button " class="btn btn-outline-info"> Approved Requests</button></a>
                <a href="#rejected-pointer"><button type="button Rejected-button " class="btn btn-outline-info"> Rejected Requests</button></a>
            </div>
        </nav>
        
        <!-- !PAGE CONTENT! -->
        <div class="w3-main" style="margin-left:340px;margin-right:40px">
            <h1 class="w3-jumbo"><b>Approval Page</b></h1>
            
            <!-- Pending -->
            <div class="w3-container" style="margin-top:80px" id="showcase">
                <h2 class="w3-xxxlarge w3-text-red" id="pending-pointer"><b>Pending Requests</b></h2>
                <hr style="width:50px;border:5px solid red" class="w3-round">
            </div>
            
            <!-- Php to get and output pending data -->
            <?Php 
            
            // Query to retrieve OrderID and Description
            if($appt==1){$sql = "SELECT requestnumber,request FROM request WHERE approval_1_status = 'Pending' AND approval_1_officer = $empid";}
            else if($appt==2){$sql = "SELECT requestnumber,request FROM request WHERE approval_2_status = 'Pending' AND approval_1_status = 'Approve' AND approval_2_officer = $empid";}
            else{$sql = "SELECT requestnumber,request FROM request WHERE approval_3_status = 'Pending' AND approval_1_status = 'Approve' AND approval_2_status = 'Approve' AND approval_3_officer = $empid";}
            
            // Execute the query
            $result = $conn->query($sql);
            
            // Check if the query was successful
            if ($result === false){die("Error executing query: " . $conn->error);}
            $penIndex = 1;
        ?>
            
            <!-- Pending Accordition -->
            <div class="w3-row-padding">
                <div class="accordion" id="accordionPanelsStayOpenExample">
                    <?php 
                    while ($row = $result->fetch_assoc())
                    {
                        ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse<?php echo $penIndex; ?>Pending" aria-expanded="true" aria-controls="panelsStayOpen-collapse<?php echo $penIndex; ?>Pending">
                                    Request <?php echo $row['requestnumber'] ; ?>
                                </button>
                            </h2>
                            <div id="panelsStayOpen-collapse<?php echo $penIndex; ?>Pending" class="accordion-collapse collapse ">
                                <div class="accordion-body">
                                    <h5 class="card-title"> <strong> <?php echo $row['request'] ; ?> </strong></h5><br>
                                    <button type="button" class="btn btn-success  mx-2 px-2 approve-button"  data-orderid="<?php echo $row['requestnumber']; ?>" onclick="buttonClick(this,'Approve')">Approve</button>
                                    <button type="button" class="btn btn-danger reject-button mx-2 px-3" data-orderid="<?php echo $row['requestnumber']; ?>"onclick="buttonClick(this, 'Reject')">Reject</button>
                                </div>
                            </div>
                        </div>
                        <?php
                            $penIndex++; 
                    } 
                ?>
                </div>
            </div>
            
            <!-- Approve -->
            <div class="w3-container" id="services" style="margin-top:75px">
                <h2 class="w3-xxxlarge w3-text-red" id="approval-pointer"><b>Approved Requests</b></h2>
                <hr style="width:50px;border:5px solid red" class="w3-round">
                <?Php 
                
                    // Query to retrieve OrderID and Description
                    if($appt==1){$sql = "SELECT requestnumber,request FROM `request` WHERE approval_1_status = 'Approve' AND approval_1_officer = $empid";}
                    else if($appt==2){$sql = "SELECT requestnumber,request FROM `request` WHERE approval_2_status = 'Approve' AND approval_2_officer = $empid";}
                    else{$sql = "SELECT requestnumber,request FROM `request` WHERE approval_3_status = 'Approve' AND approval_3_officer = $empid";}
                
                    // Execute the query
                    $result = $conn->query($sql);
                
                    // Check if the query was successful
                    if ($result === false) {die("Error executing query: " . $conn->error);}
                    $appIndex = 1;
                ?>
                
                <!-- Approve Accordition -->
                <div class="accordion" id="accordionPanelsStayOpenExample">
                    <?php 
                    while ($row = $result->fetch_assoc())
                    {
                    ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse<?php echo $appIndex; ?>Approve" aria-expanded="true" aria-controls="panelsStayOpen-collapse<?php echo $appIndex; ?>Approve">
                                Request <?php echo $row['requestnumber'];?>
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapse<?php echo $appIndex; ?>Approve" class="accordion-collapse collapse ">
                            <div class="accordion-body">
                                <h5 class="card-title"> <strong> <?php echo $row['request'] ; ?> </strong></h5><br>
                            </div>
                        </div>
                    </div>
                    <?php
                        $appIndex++; 
                    } 
                    ?>
                </div>
            </div>
            
            <!-- Rejected -->
            <div class="w3-container" id="designers" style="margin-top:75px">
                <h2 class="w3-xxxlarge w3-text-red" id="rejected-pointer"><b>Rejected Requests</b></h2>
                <hr style="width:50px;border:5px solid red" class="w3-round">
                <?Php 
                    
                    // Query to retrieve OrderID and Description
                    if($appt==1){$sql = "SELECT requestnumber,request FROM `request` WHERE approval_1_status = 'Reject' AND approval_1_officer = $empid";}
                    else if($appt==2){$sql = "SELECT requestnumber,request FROM `request` WHERE approval_2_status = 'Reject' AND approval_2_officer = $empid";}
                    else{$sql = "SELECT requestnumber,request FROM `request` WHERE approval_3_status = 'Reject' AND approval_3_officer = $empid";}
                
                    // Execute the query
                    $result = $conn->query($sql);
                
                    // Check if the query was successful
                    if ($result === false){die("Error executing query: " . $conn->error);}
                    $rejIndex = 1;
                ?>
                
                <!-- Rejected Accordition -->
                <div class="accordion" id="accordionPanelsStayOpenExample">
                    <?php 
                    while ($row = $result->fetch_assoc()){
                    ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse<?php echo $rejIndex; ?>Rejected" aria-expanded="true" aria-controls="panelsStayOpen-collapse<?php echo $rejIndex; ?>Rejected">
                                Request <?php echo $row['requestnumber'] ; ?>
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapse<?php echo $rejIndex; ?>Rejected" class="accordion-collapse collapse ">
                            <div class="accordion-body">
                                <h5 class="card-title"> <strong> <?php echo $row['request'] ; ?> </strong></h5><br>
                            </div>
                        </div>
                    </div>
                    <?php
                        $rejIndex++; 
                    } 
                    ?>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI/t1qEzrWAORou6H2DMSbcWRVJFEERA8s4eP3zE=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
    </html>