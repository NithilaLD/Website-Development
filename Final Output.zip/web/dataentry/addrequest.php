<?php 
    // Session
    include ("php/session.php");

    // Database Connection
    include ("php/dbcon.php");

    if ($conn->connect_error){die("Connection failed: " . $conn->connect_error);}
    if(isset($_POST['submit']))
    {
        //1. get the data from the form
        $rqno = $_POST['reqno'];
        $empid = $_POST['empid'];
        $description = $_POST['request'];
        $approval_1=$_POST['approval_1'];
        $approval_2=$_POST['approval_2'];
        $approval_3=$_POST['approval_3'];
        $time=time();
        
        //2. insert into database
        //create a SQL query to save or Add data
        //for numerical values we do not need to pass value inside quotes ''
        $sql = "INSERT INTO request(requestnumber,employee_id,request,rtime,approval_1_officer,approval_1_status,approval_2_officer,approval_2_status,approval_3_officer,approval_3_status)
                VALUES($rqno,$empid,'$description',CURRENT_TIMESTAMP,$approval_1,'Pending',$approval_2,'Pending',$approval_3,'Pending')";
        
        //execute the query
        $res = mysqli_query($conn, $sql);
        
        //check whether data is inserted or not
        //4. redirect with message 
        if($res == true)
        {
            //data inserted sucsessfully
            header('location:reqsucess.php');
        }
        else
        {
            //Failed to insert data
            header('location:index.php?error=true');
        }
    }
?>