<?php
  // Session
  include ("php/session.php");

  // Database Connection
  include ("php/dbcon.php");

  if ($conn->connect_error){die("Connection failed: " . $conn->connect_error);}
  $sql = "SELECT requestnumber FROM request ORDER BY requestnumber DESC LIMIT 1";
  $result = $conn->query($sql);
  if ($result->num_rows > 0)
  {
    $row = $result->fetch_all(MYSQLI_ASSOC);
    $lastRequestNumber = $row[0]['requestnumber']+1;
  }
  else{$lastRequestNumber=1;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Submission</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button>
<button class="rh-btn" onclick="location.href='requesthistory.php'">Request History</button>
      <center>
        <div class="card">
          <form action="addrequest.php" method="POST" id="form">
            <table>
              <tr><td colspan="2"><font size="14px"><b><center>Request Submission<center></b></font></td></tr>
              <tr><td><p style="color: red;display:none;" id="on">Requset Submission Failed. Please Try Again</p><br></td></tr>
              <?php
                        // Display error message if set
                        if(isset($_GET['error']))
                        {
                            ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('on').style.display = 'block';
                                    }
                                    else{window.location.href = 'index.php';}
                                </script>
                                <?php
                            }
                            $sql="SELECT * FROM approver";
                            $result=$conn->query($sql);
		                        if (!$result){die("Query failed:".$conn->error);}
                            if($result->num_rows>0)
                            {
                              $row=$result->fetch_all(MYSQLI_ASSOC);;
                              foreach ($row as $specificRowData)
                              {
                                if($specificRowData['approvertype']==1){$emid1[]=$specificRowData['employee_id'];}
                                else if($specificRowData['approvertype']==2){$emid2[]=$specificRowData['employee_id'];}
                                else {$emid3[]=$specificRowData['employee_id'];}
                              }
                            }
                      ?>
              <tr><td colspan="2" style="text-align:center"><b>Request Number</b><input type="text" class="input" name="reqno" value="<?php echo $lastRequestNumber; ?>" readonly></td></tr>
              <tr><td colspan="2"><br><center><b>Employee ID</b></center><input type="text" class="input" name="empid" required></td></tr>
              <tr><td colspan="2"><br><center><b>Request</b></center><textarea  name="request" required></textarea></td></tr>
              <tr><td><br><center><b>Approval 01</b>
              <select class="mar" name="approval_1" id="approval_1">
                <option value="4" style="text-align:center;font-weight: bold;"></option>
                <?php
                $inde=1;
                foreach ($emid1 as $emid)
                {
                  $sq="SELECT * FROM user WHERE employee_id=$emid";
                  $res=$conn->query($sq);
                  $ro=$res->fetch_all(MYSQLI_ASSOC);
                  $sRowData = $ro[0];
                  echo '<option value="'.($emid).'" style="text-align:center;font-weight: bold;">'.$sRowData['ename'].'</option>';
                  $inde++;
                }
                ?>
              </select></center>
            </td></tr>
              <tr><td><center><b>Approval 02</b>
                <select class="mar" name="approval_2" id="approval_2">
                <option value="4" style="text-align:center;font-weight: bold;"></option>
                <?php
                $inde=1;
                foreach ($emid2 as $emid)
                {
                  $sq="SELECT * FROM user WHERE employee_id=$emid";
                  $res=$conn->query($sq);
                  $ro=$res->fetch_all(MYSQLI_ASSOC);
                  $sRowData = $ro[0];
                  echo '<option value="'.($emid).'" style="text-align:center;font-weight: bold;">'.$sRowData['ename'].'</option>';
                  $inde++;
                }
                ?>    
              </select></center>
              </td></tr>
              <tr><td><center><b>Approval 03</b>
                <select class="mar" name="approval_3" id="approval_3">
                <option value="4" style="text-align:center;font-weight: bold;"></option>
                <?php
                $inde=1;
                foreach ($emid3 as $emid)
                {
                  $sq="SELECT * FROM user WHERE employee_id=$emid";
                  $res=$conn->query($sq);
                  $ro=$res->fetch_all(MYSQLI_ASSOC);
                  $sRowData = $ro[0];
                  echo '<option value="'.($emid).'" style="text-align:center;font-weight: bold;">'.$sRowData['ename'].'</option>';
                  $inde++;
                }
                ?>
                </select></center>
              </td></tr>
              <tr><td colspan="2">&nbsp;</td></tr>
              <tr><td><br><input type="submit" class="sbtn" name="submit" value="Submit"></td></tr>
            </table>
          </form>
        </div>
    </center>
    <script src="js/index.js"></script>
</body>
</html>