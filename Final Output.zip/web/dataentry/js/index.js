// JavaScript to handle custom select behavior
document.addEventListener('DOMContentLoaded', function ()
{
  var form = document.querySelector('form');
  form.addEventListener('submit', function (event)
  {
    var approval1Select = document.getElementById('approval_1');
    var approval2Select = document.getElementById('approval_2');
    var approval3Select = document.getElementById('approval_3');
    var selectedValue1 = approval1Select.options[approval1Select.selectedIndex].value;
    var selectedValue2 = approval2Select.options[approval2Select.selectedIndex].value;
    var selectedValue3 = approval3Select.options[approval3Select.selectedIndex].value;
    // Check if the selected value is the disabled "Without Content" option
    if (selectedValue1 === "4")
    {
      if (selectedValue2 === "4")
      {
        if (selectedValue3 === "4")
        {
          event.preventDefault(); // Prevent form submission
          alert('Please select Valid options for All 3 Approvals.'); // Display an error message or handle it as needed
        }
        else
        {
          event.preventDefault();
          alert('Please select  Valid options for Approval 01 & 02.');
        }
      }
      else
      {
        event.preventDefault(); // Prevent form submission
        alert('Please select a Valid option for Approval 01.'); // Display an error message or handle it as needed
      }
    }
    else if (selectedValue2 === "4")
    {
      if (selectedValue3 === "4")
      {
        event.preventDefault(); // Prevent form submission
        alert('Please select  Valid options for Approval 02 & 03.'); // Display an error message or handle it as needed
      }
      else
      {
        event.preventDefault();
        alert('Please select a Valid option for Approval 02.');
      }
    }
    else if(selectedValue3 === "4")
    {
      event.preventDefault(); // Prevent form submission
      alert('Please select a Valid option for Approval 03.'); // Display an error message or handle it as needed
    }
  });
});