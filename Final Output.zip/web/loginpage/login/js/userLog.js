    document.getElementById("signinForm").addEventListener("submit", function(event)
    {
        if (!validateForm())
        {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });
    function validateForm()
    {
        var empId = document.getElementById("empId").value;
        var pass = document.getElementById("pass").value;
        // Validate employee_id (should be only digits)
        if (!/^\d+$/.test(empId))
        {
            alert("Error: Employee ID should contain only digits.");
            return false;
        }
        // Validate password (should be only digits)
        if (!/^\d+$/.test(pass)) {
            alert("Error: Password should contain only digits.");
            return false;
        }
        return true; // Form is valid, allow submission
    }
    const passwordField = document.getElementById("pass");
    const togglePassword = document.querySelector(".password-toggle-icon i");
    togglePassword.addEventListener("click", function ()
    {
        if (passwordField.type === "password")
        {
            passwordField.type = "text";
            togglePassword.classList.remove("fa-eye");
            togglePassword.classList.add("fa-eye-slash");
        }
        else
        {
            passwordField.type = "password";
            togglePassword.classList.remove("fa-eye-slash");
            togglePassword.classList.add("fa-eye");
        }
    });
