<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Sign Up Page</title>
</head>
<body>
  <div class="wrapper">
    <div class="container main" style="width: 100%;max-width: 600px;">
        <div class="row">
            <div class="col-md-6 right" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                <div class="input-box">
                    <form id="signupForm" action="userReg.php" method="post">
                        <header style="height: 10px;">SIGN UP HERE</header>
                        <p style="color: red;display:none;position: relative;top: -20px;margin-bottom: 0;" id="an">Account Already Exists. Go To Login</p>
                        <p style="color: red;display:none;position: relative;top: -20px;margin-bottom: 0;" id="un">Please Enter The Correct Employee ID</p>
                        <p style="color: red;display:none;position: relative;top: -20px;margin-bottom: 0;" id="in">Please Enter The Correct Email</p>
                        <p style="color: red;display:none;position: relative;top: -20px;margin-bottom: 0;" id="on">This Password Is Already Taken</p>
                        <?php
                        if(isset($_GET['error']))
                        {
                            if($_GET['value']==1)
                            {
                                ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('un').style.display = 'block';
                                    }
                                    else{window.location.href = 'register.php';}
                                </script>
                                <?php
                            }
                            else if($_GET['value']==3)
                            {
                                ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('in').style.display = 'block';
                                    }
                                    else{window.location.href = 'register.php';}
                                </script>
                                <?php
                            }
                            else if($_GET['value']==4)
                            {
                                ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('on').style.display = 'block';
                                    }
                                    else{window.location.href = 'register.php';}
                                </script>
                                <?php
                            }
                            else
                            {
                            ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('an').style.display = 'block';
                                    }
                                    else{window.location.href = 'register.php';}
                                </script>
                                <?php
                            }
                        }
                        ?>
                        <div class="input-field">
                            <input type="text" class="input" id="empId" name="empId" required="" autocomplete="off" maxlength="10">
                            <label for="empid">Employee id</label>
                        </div> 
                        <div class="input-field">
                            <input type="text" class="input" id="name" name="name" required="" autocomplete="off" maxlength="50">
                            <label for="name">Name</label>
                        </div>
                        <div class="input-field">
                            <input type="email" class="input" id="email" name="email" required="" autocomplete="off" maxlength="40">
                            <label for="email">Email</label>
                        </div>
                        <div class="input-field">
                            <input type="password" class="input" id="pass" name="pass" required="" maxlength="8">
                            <label for="pass">Password</label>
                            <span class="password-toggle-icon"><i class="fas fa-eye"></i></span>
                        </div>
                        <div class="input-field">
                            <input type="password" class="input" id="rePass" name="rePass" required="" maxlength="8">
                            <label for="rePass">Re Enter Password</label>
                            <span class="repassword-toggle-icon"><i class="fas fa-eye"></i></span>
                        </div>
                        <div class="input-field">
                            <input type="text" class="input" id="dept" name="dept" required="" autocomplete="off" maxlength="40">
                            <label for="dept">Department</label>
                        </div>
                        <div class="input-field">
                            <input type="submit" class="submit" value="Sign Up" >
                        </div> 
                    </form>
                    <div class="signin">
                        <span>Already have an account? <a href="../login/LogInForm.php">Log in here</a></span>
                    </div>
                </div>  
            </div>
            
        </div>
    </div>
</div>
</body>
<script src="userReg.js"></script>
</html>
