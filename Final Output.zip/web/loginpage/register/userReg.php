<?php

// Database Connection
include ("php/dbcon.php");

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $empId = $_POST['empId'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $reenterPass = $_POST['rePass'];
    $dept = $_POST['dept'];

    // Hash the password before storing it in the database (for security)
    $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

    $checkQuery = "SELECT * FROM user WHERE employee_id='$empId' OR email='$email'";
    $result = $conn->query($checkQuery);
    $row=$result->fetch_all(MYSQLI_ASSOC);
    if ($result !== false)
    {
        $numRows = $result->num_rows;
        if ($numRows > 0)
        {
            $checkQuery2 = "SELECT * FROM user WHERE ename='$name' AND department='$dept' OR epassword='$hashedPass'";
            $result2 = $conn->query($checkQuery2);
            if ($result2 !== false)
            {
                $numRows2 = $result2->num_rows;
                if ($numRows2 > 0)
                {
                    header("Location: register.php?error=true&value=2");
                    die();
                }
                else
                {
                    for ($specificRowIndex=0;$specificRowIndex<sizeof($row);$specificRowIndex++)
						{
							$specificRowData = $row[$specificRowIndex];
							if($empId==$specificRowData['employee_id'])
                            {
                                // Employee ID already exists, display error message
                                header("Location: register.php?error=true&value=1");
                                die();
                            }
                            if($email==$specificRowData['email'])
                            {
                                // Emaial already exists, display error message
                                header("Location: register.php?error=true&value=3");
                                die();
                            }
                            if($hashedPass==$specificRowData['epassword'])
                            {
                                // Password already exists, display error message
                                header("Location: register.php?error=true&value=4");
                                die();
                            }
						}  
                }
            }
            else
            {
                $sql = "INSERT INTO user (employee_id, ename, email, epassword, department) 
                            VALUES ('$empId', '$name', '$email', '$hashedPass', '$dept')";
                    if ($conn->query($sql) === TRUE)
                    {
                        $conn->close();
                        header("Location: regSucess.php");
                    }
                    else
                    {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
            }
        }
        else
        {
            $sql = "INSERT INTO user (employee_id, ename, email, epassword, department) 
                            VALUES ('$empId', '$name', '$email', '$hashedPass', '$dept')";
                    if ($conn->query($sql) === TRUE)
                    {
                        $conn->close();
                        header("Location: regSucess.php");
                    }
                    else
                    {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
        }
    }
    else
    {
        echo "Error: " . $checkQuery . "<br>" . $conn->error;
    }
}
?>
