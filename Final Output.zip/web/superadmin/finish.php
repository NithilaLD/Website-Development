<?php
//Mail
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
include 'php/mail.php';

// Session
include ("php/session.php");

// Database Connection
include ("php/dbcon.php");

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $s=$_POST['sz'];
    for($i=1;$i<=$s;$i++)
    {
        $id=$_POST['id'.$i];
        $name=$_POST['nm'.$i];
        $email=$_POST['em'.$i];
        $type=$_POST['btnradio'.$i];
        $sql = "UPDATE user SET type = $type WHERE employee_id=$id";
        $result = mysqli_query($conn, $sql);
        if($result)
        {
            $mail = new PHPMailer(true);
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                    
            $mail->isSMTP();                                           
            $mail->Host       = $host;                    
            $mail->SMTPAuth   = true;                                   
            $mail->Username   = $username;                 
            $mail->Password   = $password;                      
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
            $mail->Port       = $port;                                    
            $mail->setFrom($sender, 'Superadmin');
            $mail->addAddress($email,$name);
            $mail->isHTML(true);                                  
            $mail->Subject    = 'Account Creation Confirmation';
            $mail->Body       = "Dear ".$name.",<br>We are thrilled to inform you that your account has been successfully created!";
            $mail->send();
        }
    }
    echo "<script>window.location.href = 'superadmin.php';</script>";
    exit();
}
?>