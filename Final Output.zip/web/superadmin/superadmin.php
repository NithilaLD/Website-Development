<?php 
    // Session
    include ("php/session.php");

    // Database Connection
    include ("php/dbcon.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Page</title>
    <link rel="stylesheet" href="css/style.css">
    <!--bostrap link-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <!--Nav bar start-->
    <nav id="navbar-example2" class="navbar bg-body-tertiary px-3 mb-3 sticky-top  navbar-dark navcolor">
        <a class="navbar-brand">Super Admin</a>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading1">Pending Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading2">Edit Users</a>
            </li>
            <div class="navlogbtn">
                <li class="nav-item">
                    <a class="nav-link "><button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button></a>
                </li>
            </div>
        </ul>
    </nav>
    <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" class="scrollspy-example bg-body-tertiary p-3 rounded-2" tabindex="0">
        <!--Nav bar End-->
        <!--Pending Request start-->
        <div id="scrollspyHeading1" class="gap">
            <div class="box container" >   
                <h4>Pending Users</h4>
                <div class="container  col-12  text-center align-items-center ">
                    <div class="container ">
                    <form  action="finish.php" method="POST"> 
                        <table class="table table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Employee ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">User Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $sql = "SELECT * FROM `user` WHERE type = ''";
                                    $result = mysqli_query($conn, $sql);
                                    if ($result)
                                    {
                                        $rn = 1;
                                        $size=mysqli_num_rows($result);
                                        while ($row = mysqli_fetch_assoc($result))
                                        {
                                            $id = $row['employee_id'];
                                            $name = $row['ename']; 
                                            $email = $row['email'];
                                            $department = $row['department'];
                                            echo '
                                                    <tr>
                                                        <th scope="row">' . $id . '<input type="text" name="id' . $rn . '" value="'.$id.'" style="display:none;"></th>
                                                        <td>' . $name . '<input type="text" name="nm' . $rn . '" value="'.$name.'" style="display:none;"></td>
                                                        <td>' . $email . '<input type="text" name="em' . $rn . '" value="'.$email.'" style="display:none;"></td>
                                                        <td>' . $department . '</td>
                                                        <td>
                                                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio1' . $rn . '" autocomplete="off" value="2">
                                                                    <label class="btn btn-outline-blue" for="btnradio1' . $rn . '">User</label>
                                                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio2' . $rn . '" autocomplete="off" value="4">
                                                                    <label class="btn btn-outline-blue" for="btnradio2' . $rn . '">Approval Officer</label>
                                                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio3' . $rn . '" autocomplete="off" value="1">
                                                                    <label class="btn btn-outline-blue" for="btnradio3' . $rn . '">Admin</label>
                                                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio4' . $rn . '" autocomplete="off" value="3">
                                                                    <label class="btn btn-outline-blue" for="btnradio4' . $rn . '">Super Admin</label>
                                                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio5' . $rn . '" autocomplete="off" value="5">
                                                                    <label class="btn btn-outline-blue" for="btnradio5' . $rn . '">Data Entry</label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                    '       ;
                                            $rn++;
                                        }
                                    }
                                    echo '<input type="text" name="sz" value="'.$size.'" style="display:none;">';
                                ?>
                            </tbody>
                        </table>
                        <?php
                            if($rn!==1)
                            {
                        ?>
                        <div id="sbtn" class="text-end"> <!-- Align the button to the right -->
                            <input type="submit" value="Save Changes" class="btn btn-primary" style="background-color:#6270EA">
                        </div>
                        <?php
                            }
                        ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--Pending Request End-->
    
    <!--Edit users Start-->
        <div id="scrollspyHeading2" class="gap">
            <div class="box container">
                <h4>Edit Users</h4>
                <div class="container   text-center align-items-center ">
                    <div class="col-6 mx-auto">
                        <form action="superadmin.php?search" method="GET">
                            <div class="input-group col-4 mb-3 search">
                                <input type="text" name="search" required class="form-control"
                                    placeholder="Enter Employee ID, Name Or Email">
                                <button class="btn btn-outline-blue" type="submit" id="button-addon2"
                                    onclick=document.getElementById("search").style.display="block" ;>Search</button>

                            </div>
                        </form>
                    </div>
                    <div class="col-12 container text-center align-items-center table-responsive">
                        <table class="table table table-hover py-3">
                            <thead>
                                <tr>
                                    <th scope="col">Employee ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Password</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">User Type</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <div id="search" style="display:none;"> 
                                    
                                    <!-- search data from search box - strart -->
                                    <?php
                                            if(isset($_GET['search']))
                                            {
                                                $searchvalues = $_GET['search'];
                                                $query = "SELECT * FROM user WHERE employee_id='$searchvalues' OR ename='$searchvalues' OR email='$searchvalues'";
                                                $query_run = mysqli_query($conn, $query);
                                                if(mysqli_num_rows($query_run) > 0) 
                                                {
                                                while($row = mysqli_fetch_array($query_run)) 
                                                {
                                                ?>
                                                    <script>var s=1;</script>
                                                    <form name="updateform" action="" method="POST">
                                                        <tr>
                                                        <td><input type="text" name="employee_id" value="<?php echo $row['employee_id'];?>" class="custom-input"></td>
                                                            <td><input type="text"  name="ename" value="<?php echo $row['ename'];?>" class="custom-input"></td>
                                                             <td><input type="email" name="email" value="<?php echo $row['email'];?>" class="custom-input"></td>
                                                             <td><input type="password" name="epassword" id="password" value="<?php echo $row['epassword'];?>" class="custom-input"></td>
                                                             <td><input type="text"  name="department" value="<?php echo $row['department'];?>" class="custom-input"></td>
                                                            <!-- make a way to add user type-->
                                                            <td>
                                                                <input type="text"  name="type" value="<?php if($row['type']==1){echo "Admin";}else if($row['type']==2){echo "User";}else if($row['type']==3){echo "Super Admin";} else if($row['type']==4){echo "Approval Officer";}else if($row['type']==5){echo "Data Entry";} else{echo "-";}?>" class="custom-input" readonly><br><br>
                                                                <?php if($row['type']==''){ ?><script>var user=1;</script><?php } ?>
                                                                <select id="userType" name="usertype">
                                                                    <option value="no">Select User Type</option>
                                                                    <option value="1" <?php if($row['type']==1){echo "Selected";}?>>Admin</option>
                                                                    <option value="2" <?php if($row['type']==2){echo "Selected";}?>>User</option>
                                                                    <option value="3" <?php if($row['type']==3){echo "Selected";}?>>Superadmin</option>
                                                                    <option value="4" <?php if($row['type']==4){echo "Selected";}?>>Approval Officer</option>
                                                                    <option value="5" <?php if($row['type']==5){echo "Selected";}?>>Data Entry</option>
                                                                </select>
                                                            </td>
                                                            <td>
                                                            <div class="updatebtn">
                                                                <input type="submit" name="update" class="btn btn-outline-success" value="Update" onclick="return validateForm()">
                                                            </div>
                                                            <div class="deletebtn">
                                                                <input type="submit" name="delete" class="btn btn-outline-danger" value="Delete">
                                                            
                                                            </div>
                                                            </td>
                                                         </tr>
                                                </form>
                                            <?php
                                    }       
                                  } else 
                                         {
                                         ?><script>var s=1;</script><tr><td colspan="7">No Records Found</td></tr><?php
                                        }
                                    }
                                    ?>
                                    <!-- search data from search box - end -->
                                   <!-- update data - strart -->
                                   <?php                   
                                    if(isset($_POST['update'])) 
                                     {
                                        $employee_id = $_POST['employee_id'];
                                        $ename = $_POST['ename'];
                                        $email = $_POST['email'];
                                        $epassword = $_POST['epassword'];
                                        $department = $_POST['department'];
                                        $usertype = $_POST['usertype'];
                                        $query = "UPDATE user SET employee_id='$_POST[employee_id]', ename='$_POST[ename]', email='$_POST[email]', epassword='$_POST[epassword]', department='$_POST[department]', type='$_POST[usertype]' where employee_id='$_POST[employee_id]'";
                                        $query_run = mysqli_query($conn, $query);
                                        if($query_run)
                                        {
                                            echo '<script>alert("Data Updated Successfully");window.location.href = "superadmin.php";</script>';
                                        }
                                        else
                                        {
                                            echo '<script> alert("Data Updated Successfully");window.location.href = "superadmin.php";</script>';
                                        }
                                        header('Location: superadmin.php');
                                    }
                                    ?>
                                        <!-- update data - end -->
                                        <!-- delete data - start -->
                                    <?php
                                        if(isset($_POST['delete'])) 
                                        {
                                            $employee_id = $_POST['employee_id'];
                                            $query = "DELETE FROM user WHERE employee_id='$_POST[employee_id]'";
                                            $query_run = mysqli_query($conn, $query);
                                            if($query_run)
                                            {
                                                echo '<script>alert("Data Deleted Successfully");window.location.href = "superadmin.php";</script>'; 
                                            }
                                            else
                                            {
                                                echo '<script> alert("Data Not Deleted");window.location.href = "superadmin.php";</script>';
                                            }
                                            header('Location: superadmin.php');
                                        }
                                    ?>
                                      <!-- delete data - end -->
                                </div>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!--Edit users End-->
    <!--Java script-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <script>
        if(window.performance.navigation.type==1){window.location.href='superadmin.php';}
        if(s==1){document.getElementById('scrollspyHeading2').scrollIntoView({ behavior: 'smooth' });}
        function validateForm()
        {
            var userType = document.getElementById("userType").value;
            if (userType === "no" && $user!==1)
            {
                alert("Please Select a User Type");
                return false; // Prevent form submission
            }
            else{return true;} // Allow form submission
        }
    </script>
</body>

</html>