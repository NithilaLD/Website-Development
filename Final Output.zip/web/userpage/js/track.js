            const one = document.querySelector(".one");
            const two = document.querySelector(".two");
            const three = document.querySelector(".three");
            const four = document.querySelector(".four");
            one.display = function()
            {
                one.classList.add("active");
                two.classList.remove("active");
                three.classList.remove("active");
                four.classList.remove("active");
                one.style.backgroundColor = "brown"; // Change color for step 1
            }
            two.display = function()
            {
                one.classList.add("active");
                two.classList.add("active");
                three.classList.remove("active");
                four.classList.remove("active");
                two.style.backgroundColor = "brown"; // Change color for step 2
            }
            three.display = function()
            {
                one.classList.add("active");
                two.classList.add("active");
                three.classList.add("active");
                four.classList.remove("active");
                three.style.backgroundColor = "brown"; // Change color for step 3
            }
            four.display = function()
            {
                one.classList.add("active");
                two.classList.add("active");
                three.classList.add("active");
                four.classList.add("active");
                four.style.backgroundColor = "brown"; // Change color for step 4
            }
            if(v==1){one.display();}
            else if(v==2){two.display();}
            else if(v==3){three.display();}
            else {four.display();}