function show()
            {
            	const hiddenElement = document.getElementById("show");
            	hiddenElement.style.display ="block";
				const shownElement = document.getElementById("track");
            	shownElement.style.display ="none";
				document.getElementById("reqhis").style.backgroundColor="#FE5BAC";
				document.getElementById("trackreq").style.backgroundColor="#8decb1";
            }
            function track()
            {
				const hiddenElement = document.getElementById("track");
            	hiddenElement.style.display ="block";
				const shownElement = document.getElementById("show");
            	shownElement.style.display ="none";
				document.getElementById("trackreq").style.backgroundColor="#1CCA5E";
				document.getElementById("reqhis").style.backgroundColor="#ffb5d8";
            }