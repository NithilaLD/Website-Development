<?php
    // Session
    include ("php/session.php");

    // Database Connection
    include ("php/dbcon.php");
?>
<html>
    <head>
        <!-- UniIcon CDN Link  -->
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <link rel="stylesheet" href="css/styletrack.css">
    </head>
    <body>
        <button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button>
        <?php
        $requestnumber=$_REQUEST['rn'];
        if ($conn->connect_error){die("Connection failed:".$conn->connect_error);}
        $sql="SELECT request.*,user.* FROM user INNER JOIN request ON user.employee_id=request.employee_id WHERE request.requestnumber=$requestnumber;";
        $result=$conn->query($sql);
	    if (!$result){die("Query failed:".$conn->error);}
        $row=$result->fetch_all(MYSQLI_ASSOC);
        $data=$row[0];
        if($data['approval_1_status']=="Pending" || $data['approval_1_status']=="Reject" || $data['approval_1_status']=="NULL"){?><script>var v=1;</script><?php }
        else if($data["approval_2_status"]=="Pending" || $data["approval_2_status"]=="Reject" || $data['approval_2_status']=="NULL"){?><script>var v=2;</script><?php }
        else if($data["approval_3_status"]=="Pending" || $data["approval_3_status"]=="Reject" || $data['approval_3_status']=="NULL"){?><script>var v=3;</script><?php }
        else{?><script>var v=4;</script><?php }
        ?>
        <div class="main">
            <div class="head"><p class="head_1">Request Number : <span><?php echo $data['requestnumber']?></span></p></div>
            <ul>
                <li>
                    <i class="icon uil uil-capture" id="i1"></i>
                    <div class="progress one">
                        <p>1</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Submitted<br><?php echo "Date : ".substr($data['rtime'], 0, 10)."<br>Time : ".substr($data['rtime'], 10, 9);?></p>
                </li>
                <li>
                    <i class="icon uil uil-clipboard-notes"></i>
                    <div class="progress two">
                        <p>2</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Approval 1<br><?php if($data['approval_1_status']=="Approve"){echo "Date : ".substr($data['approval_1_time'], 0, 10)."<br>Time : ".substr($data['approval_1_time'], 10, 9);}?></p>
                </li>
                <li>
                    <i class="icon uil uil-credit-card"></i>
                    <div class="progress three">
                        <p>3</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Approval 2<br><?php if($data['approval_1_status']=="Approve" && $data['approval_2_status']=="Approve"){echo "Date : ".substr($data['approval_2_time'], 0, 10)."<br>Time : ".substr($data['approval_2_time'], 10, 9);}?></p>
                </li>
                <li>
                    <i class="icon uil uil-exchange"></i>
                    <div class="progress four">
                        <p>4</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Approval 3<br><?php if($data['approval_1_status']=="Approve" && $data['approval_2_status']=="Approve" && $data['approval_3_status']=="Approve"){echo "Date : ".substr($data['approval_3_time'], 0, 10)."<br>Time : ".substr($data['approval_3_time'], 10, 9);}?></p>
                </li>
            </ul>
        </div>
        <script src="js/track.js"></script>
    </body>
</html>