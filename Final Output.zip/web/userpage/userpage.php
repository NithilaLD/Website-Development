<?php
	// Session
	include ("php/session.php");

	// Database Connection
	include ("php/dbcon.php");
?>
<html>
    <head>
		
    	<link rel="stylesheet" href="css/style.css">
    	<title>Request Tracking And History</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>
	<body>
	<button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button>
    	<center>
			<h1>Welcome!</h1><br><br><br>
        	<button onclick="track()" id="trackreq">Track Requests</button>
        	<button onclick="show()" id="reqhis">Request History</button>
    	</center><br><br><br>
        <?php
        if ($conn->connect_error){die("Connection failed:".$conn->connect_error);}
        $sql="SELECT request.requestnumber,user.employee_id,user.ename,user.department,request.rtime,request.approval_1_status,request.approval_2_status,request.approval_3_status FROM user INNER JOIN request ON user.employee_id=request.employee_id;";
        $result=$conn->query($sql);
		if (!$result){die("Query failed:".$conn->error);}
        ?>
    	<div id="show" style="display: none;" class="py-5 container">
			<h1><center>My Requests</center></h1>
        	<table class="table">
				<thead>
            	<tr>
                	<th scope="col">Request Number</th>
                	<th scope="col">Employee Id</th>
                	<th scope="col">Employee Name</th>
                	<th scope="col">Department</th>
                	<th scope="col">Date And Time</th>
                	<th scope="col">Status</th>
            	</tr>
				</thead>
				<tbody>
                <?php
                    if($result->num_rows>0)
                    {				
						$row=$result->fetch_all(MYSQLI_ASSOC);
						for ($specificRowIndex=0;$specificRowIndex<sizeof($row);$specificRowIndex++)
						{
							$specificRowData = $row[$specificRowIndex];
							if($specificRowData["approval_1_status"]=="Pending" || $specificRowData["approval_1_status"]=="Reject" || $specificRowData['approval_1_status']=="NULL"){$status="Submitted";}
							else if (($specificRowData["approval_2_status"]=="Pending" || $specificRowData["approval_2_status"]=="Reject" || $specificRowData['approval_2_status']=="NULL")&& $specificRowData["approval_1_status"]=="Approve"){$status="Approval 1 Done";}
							else if(($specificRowData["approval_3_status"]=="Pending" || $specificRowData["approval_3_status"]=="Reject" || $specificRowData['approval_3_status']=="NULL")&& $specificRowData["approval_2_status"]=="Approve" && $specificRowData["approval_1_status"]=="Approve"){$status="Approval 2 Done";}
							else {$status="Completed";}
							echo "<tr>";
							echo "<td>".$specificRowData["requestnumber"]."</td>";
							echo "<td>".$specificRowData["employee_id"]."</td>";
							echo "<td>".$specificRowData["ename"]."</td>";
							echo "<td>".$specificRowData["department"]."</td>";
							echo "<td>".$specificRowData["rtime"]."</td>";
							echo "<td>".$status."</td>";
							echo "</tr>";
						}
                    }
                ?>
				</tbody>
        	</table>
    	</div>
		<div id="track" style="display: none;" class="py-5 container">
			<h1><center><b><u>Pending Requests</u></b></center></h1>
    		<table class="table">
			<thead>
            	<tr>
                	<th scope="col">Request Number</th>
                	<th scope="col">Date And Time</th>
                	<th colspan="2" scope="col">Status</th>
            	</tr>
				</thead>
				<tbody>
				<?php
				if($result->num_rows>0)
				{
					for ($specificRowIndex=0;$specificRowIndex<sizeof($row);$specificRowIndex++)
					{
						$specificRowData = $row[$specificRowIndex];
						if(($specificRowData["approval_3_status"]=="Pending" || $specificRowData["approval_3_status"]=="Reject" || $specificRowData['approval_3_status']=="NULL"))
						{
							if($specificRowData["approval_1_status"]=="Pending" || $specificRowData["approval_1_status"]=="Reject" || $specificRowData['approval_1_status']=="NULL"){$status="Submitted";}
							else if (($specificRowData["approval_2_status"]=="Pending" || $specificRowData["approval_2_status"]=="Reject" || $specificRowData['approval_2_status']=="NULL")&& $specificRowData["approval_1_status"]=="Approve"){$status="Approval 1 Done";}
							else{$status="Approval 2 Done";}
							echo "<tr>";
							echo "<td>".$specificRowData["requestnumber"]."</td>";
							echo "<td>".$specificRowData["rtime"].'</td>.
								  <form method="post" action="http://localhost/web/userpage/track.php" style="margin-bottom:0;">';
							echo "<td>".$status;
							echo '<td width="100">
								<input type="hidden" name="rn" value="'.($specificRowData["requestnumber"]).'">&ensp;&ensp;
								<button type="submit" class="b">Track</button>
								</td></form>';
							echo "</tr>";
						}
					}
				}
				?>
				</tbody>
    		</table>
		</div>
        <script src="js/user.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </body>
</html>