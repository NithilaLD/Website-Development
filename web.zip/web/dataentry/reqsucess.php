<?php
session_start();
if (!isset($_SESSION['user_id']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_SESSION['timeout']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
$_SESSION['LAST_ACTIVITY'] = time();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" 
    crossorigin="anonymous">
    <title>Registration Successful</title>
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f0f0f0;
        }

        .custom-container {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        .signin
        {
            text-align: center;
            font-size: small;
            margin-top: 25px;
        }
        span a
        {
            text-decoration: none;
            font-weight: 700;
            color: #000;
            transition: .5s;
        }
        span a:hover
        {
            text-decoration: underline;
            color: #1cca5e;
        }
      .logout-btn
      {
        position: absolute;
        top: 10px;
        right: 10px;
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      .logout-btn:hover{background-color: #45a049;}
      .rh-btn
      {
        position: absolute;
        top: 10px;
        right: 100px;
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      .rh-btn:hover{background-color: #45a049;}
      .sbtn
      {
        
        cursor: pointer;
        padding: 15px;
        width: 100%;
        background-color: rgb(236, 236, 236);
        border: none;
        outline: none;
        height: 45px;
        background: #ececec;
        border-radius: 5px;
        transition: .4s;
      }
      .sbtn:hover
      {
        background: #6270eaef;
        color: #fff;
      }
    </style>
</head>
<body>
<button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button>
<button class="rh-btn" onclick="location.href='requesthistory.php'">Request History</button>
    <div class="custom-container">
        <div class="alert alert-success text-center" role="alert">
            <h4 class="alert-heading">Request Added Successfully.</h4>
        </div>
        <div class="signin">
        <span><a href="index.php">Create A New Request From Here</a></span>
        </div>
    </div>
</body>
</html>