<?php 
    session_start();
    if (!isset($_SESSION['user_id']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_SESSION['timeout']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
    $_SESSION['LAST_ACTIVITY'] = time();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
</head>
<body>
<div class="py-5 container">
<table class="table">
    <thead>
   <tr>
       <th scope="col">Request Number</th>
       <th scope="col">Empolee ID</th>
       <th scope="col">Request</th>
       <th scope="col">Date And Time</th>
       <th scope="col">Approval 1 Officer</th>
       <th scope="col">Approval 2 Officer</th>
       <th scope="col">Approval 3 Officer</th>
   </tr>
   </thead>
  <tbody>
<?php
        $conn=new mysqli("localhost","root","","userrequest");
        if ($conn->connect_error){die("Connection failed:".$conn->connect_error);}
        $sql="SELECT request.*,user.* FROM user INNER JOIN request ON user.employee_id=request.employee_id;";
        $result=$conn->query($sql);
		if (!$result){die("Query failed:".$conn->error);}
        if($result->num_rows>0)
        {
            $row=$result->fetch_all(MYSQLI_ASSOC);
            for ($specificRowIndex=0;$specificRowIndex<sizeof($row);$specificRowIndex++)
						{
							$specificRowData = $row[$specificRowIndex];
                            $a1=$specificRowData["approval_1_officer"];
                            $sql1="SELECT user.ename FROM user INNER JOIN approver ON user.employee_id=$a1";
                            $result1=$conn->query($sql1);
                            $row1=$result1->fetch_all(MYSQLI_ASSOC);
                            $specificRowData1 = $row1[0];
                            $a2=$specificRowData["approval_2_officer"];
                            $sql2="SELECT user.ename FROM user INNER JOIN approver ON user.employee_id=$a2";
                            $result2=$conn->query($sql1);
                            $row2=$result2->fetch_all(MYSQLI_ASSOC);
                            $specificRowData2 = $row2[0];
                            $a3=$specificRowData["approval_3_officer"];
                            $sql3="SELECT user.ename FROM user INNER JOIN approver ON user.employee_id=$a3";
                            $result3=$conn->query($sql3);
                            $row3=$result3->fetch_all(MYSQLI_ASSOC);
                            $specificRowData3 = $row3[0];
							echo "<tr>";
							echo "<td>".$specificRowData["requestnumber"]."</td>";
							echo "<td>".$specificRowData["employee_id"]."</td>";
							echo "<td>".$specificRowData["request"]."</td>";
							echo "<td>".$specificRowData["rtime"]."</td>";
                            echo "<td>".$specificRowData1["ename"]."</td>";
                            echo "<td>".$specificRowData2["ename"]."</td>";
                            echo "<td>".$specificRowData3["ename"]."</td>";
							echo "</tr>";
						}
                    }    
//echo "No requests to Show";?>
</tbody>
</table>
</div>
</div> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>