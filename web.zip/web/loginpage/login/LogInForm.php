<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" 
    crossorigin="anonymous">
    <title>Login Page</title>
</head>
<body>
  <div class="wrapper">
    <div class="container main" style="align-items:center;width: 100%;max-width: 600px;">
        <div class="row">
            <div class="col-md-6 right" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                <div class="input-box">
                    <form id="signinForm" action="login.php" method="post">
                        <header>LOGIN HERE</header>
                        <p style="color: red;display:none;" id="in">Invalid username or password</p>
                        <p style="color: red;display:none;text-align:center" id="on">Your Account Is Not Created Yet.<br>Wait for The Confirmation Email</p>
                        <p style="color: red;display:none;" id="un">Session Timeout. Please Login Again</p>
                        <?php
                        // Display error message if set
                        if(isset($_GET['error']))
                        {
                            if($_GET['value']==1)
                            {
                                ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('on').style.display = 'block';
                                    }
                                    else{window.location.href = 'LogInForm.php';}
                                </script>
                                <?php
                            }
                            else if($_GET['value']==2){
                            ?>
                            <script>
                                if(window.performance.navigation.type === 0)
                                {
                                    document.getElementById('in').style.display = 'block';
                                }
                                else{window.location.href = 'LogInForm.php';}
                            </script>
                            <?php
                            }
                            else{
                                ?>
                                <script>
                                    if(window.performance.navigation.type === 0)
                                    {
                                        document.getElementById('un').style.display = 'block';
                                    }
                                    else{window.location.href = 'LogInForm.php';}
                                </script>
                                <?php
                                }
                        }
                        ?>
                        <div class="input-field">
                            <input type="text" class="input" id="empId" name="empId" required="" autocomplete="off" maxlength="10">
                            <label for="empid">Employee ID</label>
                        </div> 
                        <div class="input-field">
                            <input type="password" class="input" id="pass" name="pass" required="" maxlength="8">
                            <label for="pass">Password</label>
                        </div> 
                        <div class="input-field">
                                <input type="submit" class="submit" value="Login">
                        </div> 
                    </form>
                        <div class="signin">
                            <span>Don't have an account? <a href="../register/register.php">Sign Up here</a></span>
                        </div>
                </div>  
            </div>
        </div>
    </div>
</div>
</body>
<script src="userLog.js"></script>
</html>