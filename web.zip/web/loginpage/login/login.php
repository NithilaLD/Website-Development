<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "userrequest";
    $conn = new mysqli($servername, $username, $password, $db);
    $sql = sprintf("SELECT * FROM user
                    WHERE employee_id = '%s'",
                    $conn->real_escape_string($_POST['empId']));
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();
    if (isset($user))
    {
        if ($user["type"]!=null)
        {
            if(password_verify($_POST['pass'], $user["epassword"]))
            {
                $_SESSION['user_id'] = $user['employee_id'];
                $_SESSION['timeout']= 3600;
                if(isset($_SESSION['user_id']))
                {
                    switch ($user['type'])
                    {
                        case 1:
                            // Redirect to admin page
                            header("Location: ../../admin/admin.php");
                            exit();
                        case 2:
                            // Redirect to regular user page
                            header("Location: ../../userpage/userpage.php");
                            exit();
                        case 3:
                            // Redirect to super admin user page
                            header("Location: ../../superadmin/superadmin.php");
                            exit();
                        case 4:
                            // Redirect to approval user page
                            header("Location: ../../approvalpage/approvalpage.php");
                            exit();
                        default:
                            // Redirect to data entry user page
                            header("Location: ../../dataentry/index.php");
                            exit();
                        }
                    }
                    else
                    {
                        header("Location: LogInForm.php?error=true&value=3");
                        exit();
                    }
                }
            else
            {
                header("Location: LogInForm.php?error=true&value=2");
                exit();
            }
        }
        else
        {
            
            // Redirect back to the login form on failure. change the html file to a php file and enter that name to the location.
            header("Location: LogInForm.php?error=true&value=1");
            exit();
        }
    }
    else
    {
        header("Location: logFailed.php");
        exit();
    }
}
else
{
    header("Location: LogInForm.php");
    exit();
}
?>