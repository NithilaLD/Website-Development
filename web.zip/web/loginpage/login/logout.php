<?php
// Start or resume the session
session_start();

// Destroy the session data
session_destroy();
if(session_status() !== PHP_SESSION_ACTIVE)
{   
    // Redirect to the login page
    header("Location: LogInForm.php");
    exit();
}
?>