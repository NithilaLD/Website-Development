    document.getElementById("signupForm").addEventListener("submit", function(event)
    {
        if (!validateForm())
        {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });
    function validateForm()
    {
        var empId = document.getElementById("empId").value;
        var name = document.getElementById("name").value;
        var email = document.getElementById("email").value;
        var pass = document.getElementById("pass").value;
        var rePass = document.getElementById("rePass").value;
        var dept = document.getElementById("dept").value;

        // Validate employee_id (should be only digits)
        if (!/^\d+$/.test(empId)) {
            alert("Error: Employee ID should contain only digits.");
            return false;
        }

        // Validate name (should not have any numbers)
        if (/\d/.test(name)) {
            alert("Error: Name should not contain numbers.");
            return false;
        }

        // Validate email (should be a valid email address)
        if (!/\S+@\S+\.\S+/.test(email)) {
            alert("Error: Invalid email address.");
            return false;
        }

        // Validate password (should be only digits)
        if (!/^\d+$/.test(pass)) {
            alert("Error: Password should contain only digits.");
            return false;
        }

        // Validate re-entered password
        if (pass !== rePass) {
            alert("Error: Passwords do not match.");
            return false;
        }

        // Additional checks for length limits
        if (empId.length > 10 || name.length > 50 || email.length > 40 || pass.length > 8 || dept.length > 40) {
            alert("Error: Input length exceeds the allowed limit.");
            return false;
        }
        return true; // Form is valid, allow submission
    }
