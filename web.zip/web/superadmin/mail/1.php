<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
$mail = new PHPMailer(true);
try{
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                    
    $mail->isSMTP();                                           
    $mail->Host       = 'smtp.gmail.com';                    
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'webdevops15@gmail.com';                 
    $mail->Password   = 'rwhandmwchpqjabe';                      
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
    $mail->Port       = 465;                                    
    $mail->setFrom('webdevops15@gmail.com', 'Superadmin');
    $mail->addAddress('nithila0411@gmail.com', 'Dulan Nithila Liyanarachchi');
    $mail->isHTML(true);                                  
    $mail->Subject    = 'Account Creation Confirmation';
    $mail->Body       = "Dear Dulan Nithila Liyanarachchi,<br>We are thrilled to inform you that your account has been successfully created!";
    $mail->send();
    echo 'Message has been sent';
}catch(Exception $e){echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";}