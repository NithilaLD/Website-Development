<?php 

$con = new mysqli('localhost', 'root', '', 'userrequest');

if ($con->connect_error) {
    die('Connection failed: ' . $con->connect_error);
}// else {
 //   echo 'Connection successfully';
//}

?>