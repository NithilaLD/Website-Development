<?php 
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Page</title>
    <link rel="stylesheet" href="css/style.css">
    <!--bostrap link-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <!--Nav bar start-->
    <nav id="navbar-example2" class="navbar bg-body-tertiary px-3 mb-3 sticky-top  navbar-dark navcolor">
        <a class="navbar-brand">Super Admin</a>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading1">Pending Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading2">Edit Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading3">Edit Orders</a>
            </li>
        </ul>
    </nav>
    <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%"
        data-bs-smooth-scroll="true" class="scrollspy-example bg-body-tertiary p-3 rounded-2" tabindex="0">
        <!--Nav bar End-->
        <!--Pending Request start-->
        <div id="scrollspyHeading1" class="gap">
        <div class="box container" >   
            <h4>Pending Users</h4>
            <div class="container  col-12  text-center align-items-center ">
                <div class="container ">
                    <table class="table table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">User Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Department</th>
                                <th scope="col">User Type</th>
                                <th scope="col">Operations</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM `user` WHERE type = ''";
                            $result = mysqli_query($con, $sql);

                            if ($result) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    $id = $row['employee_id'];
                                    $name = $row['ename']; 
                                    $email = $row['email'];
                                    $department = $row['department'];
                                    echo '<tr>
                                        <th scope="row">' . $id . '</th>
                                        <td>' . $name . '</td>
                                        <td>' . $email . '</td>
                                        <td>' . $department . '</td>
                            <form  action="finish.php" method="POST">          
                            <td>
                            
                                <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                   
                                <input type="radio" class="btn-check" name="btnradio" id="btnradio1"
                                        autocomplete="off" value="2" checked>
                                    <label class="btn btn-outline-blue" for="btnradio1">User</label>

                                    <input type="radio" class="btn-check" name="btnradio" id="btnradio2"
                                        autocomplete="off" value="4">
                                    <label class="btn btn-outline-blue" for="btnradio2">Approval Officer</label>

                                    <input type="radio" class="btn-check" name="btnradio" id="btnradio3"
                                        autocomplete="off" value="1">
                                    <label class="btn btn-outline-blue" for="btnradio3">Admin</label>

                                    <input type="radio" class="btn-check" name="btnradio" id="btnradio4"
                                        autocomplete="off" value="3">
                                    <label class="btn btn-outline-blue" for="btnradio4">Super Admin</label>

                                    <input type="radio" class="btn-check" name="btnradio" id="btnradio4"
                                        autocomplete="off" value="5">
                                    <label class="btn btn-outline-blue" for="btnradio4">Data Entry</label>
                                </div>
                                </td>
                                <td>
                        
                                 <button class="btn btn-primary">Finish</button>
                                 
                                </td>
                                </form>
                                    </tr>';
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

                        
        <!--Pending Request End-->
        <!--Edit users Start-->
        <div id="scrollspyHeading2" class="gap">
        <div class="box container">
            <h4>Edit Users</h4>
            <div class="container   text-center align-items-center ">
                <div class="col-6 mx-auto">
                    <form action="" method="GET">
                    <div class="input-group col-4 mb-3 search">
                         <input type="text" name="search" required value="<?php if(isset($_GET['search'])) {echo $_GET['search'];}?>" class="form-control" placeholder="Enter ID or User name">
                         <button class="btn btn-outline-blue" type="submit" id="button-addon2">Search</button>
                  </div>
                  </form>
                </div>
                  <div class="col-12 ">
                <table class="table table table-hover py-3">
                    <thead>
                        <tr>  
                            <th scope="col">ID</th>
                            <th scope="col">User Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Password</th>
                            <th scope="col">Department</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                                        if(isset($_GET['search']))
                                        {
                                            $filtervalues = $_GET['search'];
                                            $query= "SELECT * FROM users WHERE  concat(employee_id,ename,email) LIKE '%$filtervalues%'";
                                            $query_run = mysqli_query($con,$query);

                                            if(mysqli_num_rows($query_run)>0)
                                            {
                                                foreach($query_run as $items)
                                                {
                                                        ?>
                                                  <tr>
                                                            <td><?= $items['employee_id'];?></td>
                                                            <td><?= $items['ename'];?></td>
                                                            <td><?= $items['email'];?></td>
                                                            <td><?= $items['epassword'];?></td>
                                                            <td><?= $items['department'];?></td>
                                                            <td><?= $items['type'];?></td>
                                                 </tr>
                                                        <?php
                                                }
                                            }
                                            else
                                            {
                                                ?>
                                                <tr>
                                                        <td colspan="4">No Record Found</td>
                                                </tr>
                                                 <?php
                                            }
                                        }
                            ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
        <!--Edit users End-->
        <!--Edit Request start-->
        <div id="scrollspyHeading3" class="gap">
        <div class="box container">
            <h4>Edit Request</h4>
            <div class="container  col-12   text-center align-items-center ">
                <p>...</p>
            </div>
        </div>
    </div>
    </div>
    <!--Edit users End-->
    <!--Java script-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
</body>
</html>
