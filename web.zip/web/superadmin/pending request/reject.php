<?php 

include 'connect.php';
if(isset($_GET['deleteid'])){

    $id=$_GET['deleteid'];

    $sql="delete from 'user' where id=$id";
    $result=mysqli_query($con,$sql);
    if($result){
        echo "Successfully Rejected";
    }else{
        die(mysqli_error($con));
    }
}

?>