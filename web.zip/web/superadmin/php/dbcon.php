<?php 

$conn=new mysqli("localhost","root","","userrequest");
if ($conn->connect_error){die("Connection failed:".$conn->connect_error);}

?>