<?php
$host='smtp.gmail.com';
$username='webdevops15@gmail.com';
$password='rwhandmwchpqjabe';
$port=465;
$sender='webdevops15@gmail.com';
?>