<?php 
session_start();
if (!isset($_SESSION['user_id']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_SESSION['timeout']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
$_SESSION['LAST_ACTIVITY'] = time();
include ("php/dbcon.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Page</title>
    <link rel="stylesheet" href="css/style.css">
    <!--bostrap link-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
    .btn-check:checked + .btn-outline-blue
    {
            background-color: #6270EA;
            color: #FFFFFF !important;
    }
    #mail{color:#6270EA;}
    #sbtn{color:#6270EA;}
    </style>
</head>
<body>
    <!--Nav bar start-->
    <nav id="navbar-example2" class="navbar bg-body-tertiary px-3 mb-3 sticky-top  navbar-dark navcolor">
        <a class="navbar-brand">Super Admin</a>
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading1">Pending Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading2">Edit Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#scrollspyHeading3">Edit Requests</a>
            </li>
            <div class="navlogbtn">
                <li class="nav-item">
                    <a class="nav-link "><button class="logout-btn"
                            onclick="location.href='../loginpage/login/Logout.php'">Logout</button></a>
                </li>
            </div>
        </ul>
    </nav>
    <div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%"
        data-bs-smooth-scroll="true" class="scrollspy-example bg-body-tertiary p-3 rounded-2" tabindex="0">
        <!--Nav bar End-->
        <!--Pending Request start-->
        <div id="scrollspyHeading1" class="gap">
        <div class="box container" >   
            <h4>Pending Users</h4>
            <div class="container  col-12  text-center align-items-center ">
                <div class="container ">
                <form  action="finish.php" method="POST"> 
                    <table class="table table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">User Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Department</th>
                                <th scope="col">User Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM `user` WHERE type = ''";
                            $result = mysqli_query($conn, $sql);
                            if ($result)
                            {
                                $rn = 1;
                                $size=mysqli_num_rows($result);
                                while ($row = mysqli_fetch_assoc($result))
                                {
                                    $id = $row['employee_id'];
                                    $name = $row['ename']; 
                                    $email = $row['email'];
                                    $department = $row['department'];
                                    echo '
                    <tr>
                        <th scope="row">' . $id . '<input type="text" name="id' . $rn . '" value="'.$id.'" style="display:none;"></th>
                        <td>' . $name . '<input type="text" name="nm' . $rn . '" value="'.$name.'" style="display:none;"></td>
                        <td>' . $email . '<input type="text" name="em' . $rn . '" value="'.$email.'" style="display:none;"></td>
                        <td>' . $department . '</td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio1' . $rn . '" autocomplete="off" value="2">
                                    <label class="btn btn-outline-blue" for="btnradio1' . $rn . '">User</label>
                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio2' . $rn . '" autocomplete="off" value="4">
                                    <label class="btn btn-outline-blue" for="btnradio2' . $rn . '">Approval Officer</label>
                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio3' . $rn . '" autocomplete="off" value="1">
                                    <label class="btn btn-outline-blue" for="btnradio3' . $rn . '">Admin</label>
                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio4' . $rn . '" autocomplete="off" value="3">
                                    <label class="btn btn-outline-blue" for="btnradio4' . $rn . '">Super Admin</label>
                                <input type="radio" class="btn-check" name="btnradio' . $rn . '" id="btnradio5' . $rn . '" autocomplete="off" value="5">
                                    <label class="btn btn-outline-blue" for="btnradio5' . $rn . '">Data Entry</label>
                                </div>
                        </td>
                    </tr>
                                
                                    ';
                                    $rn++;
                                }
                            }
                            echo '<input type="text" name="sz" value="'.$size.'" style="display:none;">';
                            ?>
                        </tbody>
                    </table>
                    <?php
                    if($rn!==1)
                    {
                        ?>
                        <div id="sbtn" class="text-end"> <!-- Align the button to the right -->
                            <input type="submit" value="Save Changes" class="btn btn-primary" style="background-color:#6270EA">
                        </div>
                        <?php
                    }
                    ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

                        
        <!--Pending Request End-->
        <!--Edit users Start-->
        <div id="scrollspyHeading2" class="gap">
            <div class="box container">
                <h4>Edit Users</h4>
                <div class="container   text-center align-items-center ">
                    <div class="col-6 mx-auto">
                        <form action="superadmin.php?search" method="GET">
                            <div class="input-group col-4 mb-3 search">
                                <input type="text" name="search" required class="form-control"
                                    placeholder="Enter Employee ID, Name Or Email">
                                <button class="btn btn-outline-blue" type="submit" id="button-addon2"
                                    onclick=document.getElementById("search").style.display="block" ;>Search</button>

                            </div>
                        </form>
                    </div>
                    <div class="col-12" >
                        <table class="table table table-hover py-3">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">User Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Password</th>
                                    <th scope="col">Department</th>
                                    <th scope="col">User Type</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <div id="search" style="display:none;">
                                    <?php
                                            if(isset($_GET['search']))
                                            {
                                                $searchvalues = $_GET['search'];
                                                $query = "SELECT * FROM user WHERE employee_id='$searchvalues' OR ename='$searchvalues' OR email='$searchvalues'";
                                                $query_run = mysqli_query($conn, $query);
                                                if(mysqli_num_rows($query_run) > 0) 
                                                {
                                                while($row = mysqli_fetch_array($query_run)) 
                                                {
                                                ?>
                                                    <script>var s=1;</script>
                                                    <form action="" method="GET">
                                                        <tr>
                                                          <td><?php echo $row['employee_id'];?></td>
                                                            <td><?php echo $row['ename'];?></td>
                                                             <td><?php echo $row['email'];?></td>
                                                            <td><?php echo str_repeat(".", strlen($row['epassword']));?></td>
                                                             <td><?php echo $row['department'];?></td>
                                                            <td><?php echo $row['type'];?></td>
                                                            <td>
                                                             <div class="updatebtn">
                                                              <button type="update" class="btn btn-outline-orange">Update</button>
                                                            </div>
                                                            <div class="deletebtn">
                                                             <button type="delete"  class="btn btn-outline-danger">Delete</button>
                                                            </div>
                                                         </tr>
                                                </form>
                                            <?php
                                    }       
                                  } else 
                                         {
                                         ?><tr><td colspan="7">No Records Found</td></tr><?php
                                        }
                                    }
                                    ?>
                                </div>
                    </div>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--Edit users End-->
    <!--Edit Request start-->
    <div id="scrollspyHeading3" class="gap">
        <div class="box container">
            <h4>Edit Requests</h4>
            <div class="container  col-12   text-center align-items-center ">
                <p>...</p>
            </div>
        </div>
    </div>
    </div>
    <!--Edit users End-->

    <!--Java script-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <script>
        if(window.performance.navigation.type==1){window.location.href='superadmin.php';}
        if(s==1){document.getElementById('scrollspyHeading2').scrollIntoView({ behavior: 'smooth' });}
    </script>
</body>

</html>