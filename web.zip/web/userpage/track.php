<?php
session_start();
if (!isset($_SESSION['user_id']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_SESSION['timeout']))
{
    session_unset();
    session_destroy();
    if(session_status() !== PHP_SESSION_ACTIVE)
    {
        header("Location: ../loginpage/login/LogInForm.php?error=true&value=3");
        exit();
    }
}
$_SESSION['LAST_ACTIVITY'] = time();
?>
<html>
    <head>
        <!-- UniIcon CDN Link  -->
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <style>
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        @font-face
        {
            font-family: pop;
            src: url(./Fonts/Poppins-Medium.ttf);
        }
        .main
        {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: pop;
            flex-direction: column;
        }
        .head{text-align: center;}
        .head_1
        {
            font-size: 30px;
            font-weight: 600;
            color: #333;
        }
        .head_1 span{color: brown;}
        .head_2
        {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-top: 3px;
        }
        ul
        {
            display: flex;
            margin-top: 80px;
        }
        ul li
        {
            list-style: none;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        ul li .icon
        {
            font-size: 35px;
            color: brown;
            margin: 0 60px;
        }
        ul li .text
        {
            font-size: 14px;
            font-weight: 600;
            color: brown;
            text-align: center;
        }
        /* Progress Div Css  */
        ul li .progress
        {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: grey;
            margin: 14px 0;
            display: grid;
            place-items: center;
            color: #fff;
            position: relative;
            cursor: pointer;
        }
        .progress::after
        {
            content: " ";
            position: absolute;
            width: 125px;
            height: 5px;
           background-color: grey;
            right: 30px;
        }
        .one::after
        {
            width: 0;
            height: 0;
        }
        ul li .progress .uil{display: none;}
        ul li .progress p{font-size: 13px;}
        /* Active Css  */
        ul li .active
        {
            background-color:brown;
            display: grid;
            place-items: center;
        }
        li .active::after{background-color: brown;}
        ul li .active p{display: none;}
        ul li .active .uil
        {
            font-size: 20px;
            display: flex;
        }
        ul li.active .text {color: goldenrod;}
        /* Responsive Css  */
        @media (max-width: 980px)
        {
            ul{flex-direction: column;}
            ul li{flex-direction: row;}
            ul li .progress{margin: 0 30px;}
            .progress::after
            {
                width: 5px;
                height: 55px;
                bottom: 30px;
                left: 50%;
                transform: translateX(-50%);
                z-index: -1;
            }
            .one::after{height: 0;}
            ul li .icon{margin: 15px 0;}
        }
        @media (max-width:600px)
        {
            .head .head_1{font-size: 24px;}
            .head .head_2{font-size: 16px;}
        }
        .logout-btn
        {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #1CCA5E;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .logout-btn:hover{background-color: #6270EA;}
        </style>
    </head>
    <body>
        <button class="logout-btn" onclick="location.href='../loginpage/login/Logout.php'">Logout</button>
        <?php
        $requestnumber=$_REQUEST['rn'];
        $conn=new mysqli("localhost","root","","userrequest");
        if ($conn->connect_error){die("Connection failed:".$conn->connect_error);}
        $sql="SELECT request.*,user.* FROM user INNER JOIN request ON user.employee_id=request.employee_id WHERE request.requestnumber=$requestnumber;";
        $result=$conn->query($sql);
	    if (!$result){die("Query failed:".$conn->error);}
        $row=$result->fetch_all(MYSQLI_ASSOC);
        $data=$row[0];
        if($data['approval_1_time']==NULL){?><script>one.display();</script><?php }
        else if($data['approval_2_time']==NULL){?><script>two.display();</script><?php }
        else if($data['approval_3_time']==NULL){?><script>three.display();</script><?php }
        else{?><script>four.display();</script><?php }
        ?>
        <div class="main">
            <div class="head"><p class="head_1">Request Number : <span><?php echo $data['requestnumber']?></span></p></div>
            <ul>
                <li>
                    <i class="icon uil uil-capture" id="i1"></i>
                    <div class="progress one">
                        <p>1</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Submitted<br><?php echo "Date : ".substr($data['rtime'], 0, 10)."<br>Time : ".substr($data['rtime'], 10, 9);?></p>
                </li>
                <li>
                    <i class="icon uil uil-clipboard-notes"></i>
                    <div class="progress two">
                        <p>2</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Approval 1<br><?php if($data['approval_1_time']==NULL){echo "";}else{echo "Date : ".substr($data['approval_1_time'], 0, 10)."<br>Time : ".substr($data['approval_1_time'], 10, 9);}?></p>
                </li>
                <li>
                    <i class="icon uil uil-credit-card"></i>
                    <div class="progress three">
                        <p>3</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Approval 2<br><?php if($data['approval_2_time']==NULL){echo "";}else{echo "Date : ".substr($data['approval_2_time'], 0, 10)."<br>Time : ".substr($data['approval_2_time'], 10, 9);}?></p>
                </li>
                <li>
                    <i class="icon uil uil-exchange"></i>
                    <div class="progress four">
                        <p>4</p>
                        <i class="uil uil-check"></i>
                    </div>
                    <p class="text">Approval 3<br><?php if($data['approval_3_time']==NULL){echo "";}else{echo "Date : ".substr($data['approval_3_time'], 0, 10)."<br>Time : ".substr($data['approval_3_time'], 10, 9);}?></p>
                </li>
            </ul>
        </div>
        <script>
            const one = document.querySelector(".one");
            const two = document.querySelector(".two");
            const three = document.querySelector(".three");
            const four = document.querySelector(".four");
            one.display = function()
            {
                one.classList.add("active");
                two.classList.remove("active");
                three.classList.remove("active");
                four.classList.remove("active");
                one.style.backgroundColor = "brown"; // Change color for step 1
            }
            two.display = function()
            {
                one.classList.add("active");
                two.classList.add("active");
                three.classList.remove("active");
                four.classList.remove("active");
                two.style.backgroundColor = "brown"; // Change color for step 2
            }
            three.display = function()
            {
                one.classList.add("active");
                two.classList.add("active");
                three.classList.add("active");
                four.classList.remove("active");
                three.style.backgroundColor = "brown"; // Change color for step 3
            }
            four.display = function()
            {
                one.classList.add("active");
                two.classList.add("active");
                three.classList.add("active");
                four.classList.add("active");
                four.style.backgroundColor = "brown"; // Change color for step 4
            }
            // Call the appropriate display function based on the status
            <?php
                if ($data['approval_1_time'] == NULL)
                {
            ?>
                one.display();
            <?php
                } 
                else if ($data['approval_2_time'] == NULL)
                {
            ?>
                two.display();
            <?php
                } 
                else if ($data['approval_3_time'] == NULL)
                {
            ?>
                three.display();
            <?php
                } 
                else 
                {
            ?>
                four.display();
            <?php
                }
            ?>
        </script>
    </body>
</html>